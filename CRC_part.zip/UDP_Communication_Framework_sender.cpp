#define _WIN32_WINNT 0x0600
#pragma comment(lib, "ws2_32.lib")
#include "stdafx.h"
#include <winsock2.h>
#include "ws2tcpip.h"
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <time.h>

#include "SHA256.h"
#include "CRC32.h"

// Stop-and-Wait parameters
#define MAX_RETRIES 500
#define TIMEOUT_MS  1000  // 1 second timeout for ACK/NACK

#define TARGET_IP   "127.0.0.2"
#define LOCAL_IP    "127.0.0.3"
#define BUFFERS_LEN 1024

// Uncomment for receiver or sender mode
#define SENDER
//#define RECEIVER

#ifdef SENDER
#define TARGET_PORT 14000
#define LOCAL_PORT  15000
#endif

#ifdef RECEIVER
#define TARGET_PORT 8888
#define LOCAL_PORT  5555
#endif

void InitWinsock() {
    WSADATA wsaData;
    WSAStartup(MAKEWORD(2, 2), &wsaData);
}

// Set receive timeout on a socket
int set_socket_timeout(SOCKET s, int timeout_ms) {
    int tv = timeout_ms;
    return setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, (const char*)&tv, sizeof(tv));
}

// Implement the file hash function using SHA-256
int compute_file_hash(const char *filename, char *hash_str, size_t hash_str_size) {
    try {
        std::string hash = compute_sha256(filename); 
        if (hash.size() < hash_str_size) {
            strncpy(hash_str, hash.c_str(), hash_str_size - 1);
            hash_str[hash_str_size - 1] = '\0';
            return 0;
        } else {
            strncpy(hash_str, hash.c_str(), hash_str_size - 1);
            hash_str[hash_str_size - 1] = '\0';
            return 0;
        }
    } catch (const std::exception &e) {
        fprintf(stderr, "compute_file_hash error: %s\n", e.what());
        return -1;
    }
}


int send_packet_and_wait_ack(SOCKET socketS, struct sockaddr_in *addrDest,
                             const char* packet_type,
                             uint32_t seq_num,
                             const unsigned char* payload, size_t payload_len)
{
    unsigned char buffer[BUFFERS_LEN];

    memcpy(buffer, packet_type, 4);
    uint32_t net_seq = htonl(seq_num);
    memcpy(buffer+4, &net_seq, 4);

    memset(buffer+8, 0, 4);

    if (payload_len > BUFFERS_LEN - 12) {
        printf("Payload too large!\n");
        return -1;
    }
    memcpy(buffer+12, payload, payload_len);
    uint32_t crc = compute_crc32((const char*)payload, payload_len);
    uint32_t net_crc = htonl(crc);
    memcpy(buffer+8, &net_crc, 4);
    int attempt = 0;

    char ack_buffer[BUFFERS_LEN];
    struct sockaddr_in from;
    from.sin_family = AF_INET;
    from.sin_port = htons(TARGET_PORT);
    InetPton(AF_INET, _T(TARGET_IP), &from.sin_addr.s_addr);
    int fromlen = sizeof(from);

    struct sockaddr_in dest;
    dest.sin_family = AF_INET;
    dest.sin_port = htons(TARGET_PORT);
    InetPton(AF_INET, _T(TARGET_IP), &dest.sin_addr.s_addr);
    int destlen = sizeof(dest);


    while (attempt < MAX_RETRIES) {
        int packet_size = (int)(12 + payload_len);
        sendto(socketS, (const char*)buffer, packet_size, 0, (sockaddr*)addrDest, sizeof(*addrDest));

        int received = recvfrom(socketS, ack_buffer, BUFFERS_LEN, 0, (sockaddr*)&from, &fromlen);
        if (received == SOCKET_ERROR) {
            printf("Timeout waiting for ACK/NACK for seq=%u, attempt=%d\n", seq_num, attempt);
            attempt++;
            continue;
        }

        if (received < BUFFERS_LEN) {
            ack_buffer[received] = '\0';
        } else {
            ack_buffer[BUFFERS_LEN-1] = '\0';
        }

        if (strncmp(ack_buffer, "ACK=", 4) == 0) {
            uint32_t rseq = (uint32_t)atoi(ack_buffer+4);
            if (rseq == seq_num) {
                printf("Received ACK for seq_num=%u\n", seq_num);
                return 0; 
            } else {
                printf("ACK with wrong seq_num=%u (expected=%u)\n", rseq, seq_num);
                attempt++;
            }
        } else if (strncmp(ack_buffer, "NACK=", 5) == 0) {
            uint32_t rseq = (uint32_t)atoi(ack_buffer+5);
            if (rseq == seq_num) {
                printf("NACK for seq_num=%u. Resending...\n", seq_num);
                attempt++;
            } else {
                printf("NACK with wrong seq_num. attempt=%d\n", attempt);
                attempt++;
            }
        } else {
            // Unknown response, retry
            printf("Unknown response '%s'. Retrying...\n", ack_buffer);
            attempt++;
        }
    }

    printf("Failed to get ACK after %d attempts for seq=%u. Aborting.\n", MAX_RETRIES, seq_num);
    return -1;
}


int main() {
    SOCKET socketS;
    InitWinsock();

    struct sockaddr_in local;
    struct sockaddr_in addrDest;

    local.sin_family = AF_INET;
    local.sin_port = htons(LOCAL_PORT);
    InetPton(AF_INET, _T(LOCAL_IP), &local.sin_addr.s_addr);

    socketS = socket(AF_INET, SOCK_DGRAM, 0);
    if (bind(socketS, (sockaddr*)&local, sizeof(local)) != 0) {
        printf("Binding error!\n");
        getchar(); // wait for press Enter
        return 1;
    }

#ifdef SENDER
    // Set target address
    addrDest.sin_family = AF_INET;
    addrDest.sin_port = htons(TARGET_PORT);
    InetPton(AF_INET, _T(TARGET_IP), &addrDest.sin_addr.s_addr);

    // Open the file to send
    const char* filename = "test.jpg";
    FILE* f = fopen(filename, "rb");
    if(!f) {
        printf("Error opening file: %s\n", filename);
        closesocket(socketS);
        WSACleanup();
        return 1;
    }

    // Compute file size
    fseek(f, 0, SEEK_END);
    long filesize = ftell(f);
    fseek(f, 0, SEEK_SET);

    char filehash[128] = {0};
    if (compute_file_hash(filename, filehash, sizeof(filehash)) != 0) {
        printf("Error computing file hash.\n");
        fclose(f);
        closesocket(socketS);
        WSACleanup();
        return 1;
    }
    // Send control packets: NAME, SIZE, HASH, START
    char buffer_tx[BUFFERS_LEN];
    uint32_t seq_num = 0;  // sequence number for each packet
    set_socket_timeout(socketS, TIMEOUT_MS);

    // NAME
    {
        char payload[512];
        snprintf(payload, sizeof(payload), "%s", filename);
        if (send_packet_and_wait_ack(socketS, &addrDest, "NAME", seq_num++, (const unsigned char*)payload, strlen(payload)) != 0) {
            // error
            closesocket(socketS);
            WSACleanup();
            return 1;
        }
    }

    // SIZE
    {
        char payload[512];
        snprintf(payload, sizeof(payload), "%ld", filesize);
        if (send_packet_and_wait_ack(socketS, &addrDest, "SIZE", seq_num++, (const unsigned char*)payload, strlen(payload)) != 0) {
            // error
            closesocket(socketS);
            WSACleanup();
            return 1;
        }
    }

    // HASH
    {
        char payload[512];
        snprintf(payload, sizeof(payload), "%s", filehash);
        if (send_packet_and_wait_ack(socketS, &addrDest, "HASH", seq_num++, (const unsigned char*)payload, strlen(payload)) != 0) {
            // error
            closesocket(socketS);
            WSACleanup();
            return 1;
        }
    }

    // START
    {
        char payload[1];
        if (send_packet_and_wait_ack(socketS, &addrDest, "STAR", seq_num++, (const unsigned char*)payload, 0) != 0) {
            // error
            closesocket(socketS);
            WSACleanup();
            return 1;
        }
    }


    unsigned char data_packet[BUFFERS_LEN - 12];
    const int header_size = 4;
    const int max_data_len = BUFFERS_LEN - 12 - header_size; // 1008 bytes
    uint32_t offset = 0;
    size_t bytes_read = 0;

    do {
        bytes_read = fread(data_packet + header_size, 1, max_data_len, f);
        if (bytes_read > 0) {
            // Build the packet

            uint32_t net_offset = htonl(offset);
            memcpy(data_packet, &net_offset, 4);

            if (send_packet_and_wait_ack(socketS, &addrDest, "DATA", seq_num++, (const unsigned char*)data_packet, (int)(header_size + bytes_read)) != 0) {
                // error
                closesocket(socketS);
                WSACleanup();
                return 1;
            }
            offset += (uint32_t)bytes_read;
        }
    } while (bytes_read == max_data_len);

    // Send STOP
    char payload[1];
        if (send_packet_and_wait_ack(socketS, &addrDest, "STOP", seq_num++, (const unsigned char*)payload, 0) != 0) {
            // error
            closesocket(socketS);
            WSACleanup();
            return 1;
        }

    // todo: wait for FILEOK or FILECORRUPT

    fclose(f);
    closesocket(socketS);
    WSACleanup();

    printf("File transmission completed.\n");
#endif

    getchar();
    return 0;
}
