#define _WIN32_WINNT 0x0600
#pragma comment(lib, "ws2_32.lib")
#include "stdafx.h"
#include <winsock2.h>
#include "ws2tcpip.h"
#include <stdio.h>
#include <stdint.h>
#include <string.h>

#include "CRC32.h"
#include "SHA256.h"

#define TARGET_IP   "127.0.0.3"
#define LOCAL_IP    "127.0.0.2"
#define BUFFERS_LEN 1024

//#define SENDER
#define RECEIVER

#ifdef SENDER
#define TARGET_PORT 14000
#define LOCAL_PORT  15000
#endif

#ifdef RECEIVER
#define TARGET_PORT 15001
#define LOCAL_PORT  14001
#endif


int compute_file_hash(const char *filename, char *hash_str, size_t hash_str_size) {
    try {
        std::string hash = compute_sha256(filename); 
        if (hash.size() < hash_str_size) {
            strncpy(hash_str, hash.c_str(), hash_str_size - 1);
            hash_str[hash_str_size - 1] = '\0';
            return 0;
        } else {
            strncpy(hash_str, hash.c_str(), hash_str_size - 1);
            hash_str[hash_str_size - 1] = '\0';
            return 0;
        }
    } catch (const std::exception &e) {
        fprintf(stderr, "compute_file_hash error: %s\n", e.what());
        return -1;
    }
}

int main() {
    WSADATA wsaData;
    WSAStartup(MAKEWORD(2, 2), &wsaData);

    SOCKET socketS = socket(AF_INET, SOCK_DGRAM, 0);
    if (socketS == INVALID_SOCKET) {
        printf("Error creating socket.\n");
        return 1;
    }

    struct sockaddr_in local;
    local.sin_family = AF_INET;
    local.sin_port = htons(LOCAL_PORT);
    InetPton(AF_INET, _T(LOCAL_IP), &local.sin_addr.s_addr);

    if (bind(socketS, (struct sockaddr*)&local, sizeof(local)) != 0) {
        printf("Binding error!\n");
        closesocket(socketS);
        WSACleanup();
        return 1;
    }

#ifdef RECEIVER
    printf("Receiver is waiting for datagrams...\n");

    char buffer_rx[BUFFERS_LEN];
    long expected_size = 0;
    FILE* f = NULL; 
    int started = 0;      
    int done = 0;         
    char filename[256] = {0};
    char expected_hash[128] = {0};
    uint32_t expected_seq_num = 0;

    struct sockaddr_in from;
    from.sin_family = AF_INET;
    from.sin_port = htons(TARGET_PORT);
    InetPton(AF_INET, _T(TARGET_IP), &from.sin_addr.s_addr);
    int fromlen = sizeof(from);


    struct sockaddr_in dest;
    dest.sin_family = AF_INET;
    dest.sin_port = htons(TARGET_PORT);
    InetPton(AF_INET, _T(TARGET_IP), &dest.sin_addr.s_addr);
    int destlen = sizeof(dest);

    while(!done) {
        int received = recvfrom(socketS, buffer_rx, BUFFERS_LEN, 0, (sockaddr*)&from, &fromlen);
        if (received == SOCKET_ERROR) {
            printf("recvfrom error!\n");
            break;
        }

        if (received < 12) {
            printf("Packet too short, ignoring.\n");
            continue;
        }

        char type[5];
        memcpy(type, buffer_rx, 4);
        type[4] = '\0';

        uint32_t net_seq;
        memcpy(&net_seq, buffer_rx+4, 4);
        uint32_t seq_num = ntohl(net_seq);

        uint32_t net_crc;
        memcpy(&net_crc, buffer_rx+8, 4);
        uint32_t pkt_crc = ntohl(net_crc);
        const unsigned char* payload_data = (const unsigned char*)(buffer_rx + 12);
        int payload_len = received - 12;

        // Compute CRC over payload
        uint32_t calc_crc = compute_crc32((const char*)payload_data, (size_t)payload_len);

        char resp_msg[128];

        if (calc_crc != pkt_crc) {
            // CRC mismatch
            printf("CRC error for seq=%u, type=%s. Sending NACK.\n", seq_num, type);
            snprintf(resp_msg, sizeof(resp_msg), "NACK=%u", seq_num);
            sendto(socketS, resp_msg, (int)strlen(resp_msg), 0, (struct sockaddr*)&dest, sizeof(dest));
            continue;
        }

        if (strcmp(type, "NAME") == 0) {
            if (seq_num > expected_seq_num) {
                printf("Unexpected seq_num for NAME. Got %u, expected %u. NACK.\n", seq_num, expected_seq_num);
                snprintf(resp_msg, sizeof(resp_msg), "NACK=%u", seq_num);
                sendto(socketS, resp_msg, (int)strlen(resp_msg), 0, (struct sockaddr*)&dest, sizeof(dest));
                continue;
            }else if (seq_num < expected_seq_num) {
                printf("Already received seq_num . Got %u, expected %u. ACK.\n", seq_num, expected_seq_num);
                snprintf(resp_msg, sizeof(resp_msg), "ACK=%u", seq_num);
                sendto(socketS, resp_msg, (int)strlen(resp_msg), 0, (struct sockaddr*)&dest, sizeof(dest));
                continue;
            }

            if (payload_len <= 0 || payload_len >= (int)sizeof(filename)) {
                // Invalid payload
                printf("Invalid NAME payload. NACK.\n");
                snprintf(resp_msg, sizeof(resp_msg), "NACK=%u", seq_num);
                sendto(socketS, resp_msg, (int)strlen(resp_msg), 0, (struct sockaddr*)&dest, sizeof(dest));
                continue;
            }
            memcpy(filename, payload_data, payload_len);
            filename[payload_len] = '\0';

            if (f) {
                fclose(f);
                f = NULL;
            }
            char newfilename[512];
            snprintf(newfilename, sizeof(newfilename), "Received_%s", filename);
            f = fopen(newfilename, "wb");
            if(!f) {
                printf("Error creating file: %s\n", newfilename);
                snprintf(resp_msg, sizeof(resp_msg), "NACK=%u", seq_num);
                sendto(socketS, resp_msg, (int)strlen(resp_msg), 0, (struct sockaddr*)&dest, sizeof(dest));
                continue;
            }
            printf("Receiving file: %s\n", filename);

            expected_seq_num++;
            snprintf(resp_msg, sizeof(resp_msg), "ACK=%u", seq_num);
            sendto(socketS, resp_msg, (int)strlen(resp_msg), 0, (struct sockaddr*)&dest, sizeof(dest));

        } else if (strcmp(type, "SIZE") == 0) {
            if (seq_num > expected_seq_num) {
                printf("Unexpected seq_num for SIZE. Got %u, expected %u. NACK.\n", seq_num, expected_seq_num);
                snprintf(resp_msg, sizeof(resp_msg), "NACK=%u", seq_num);
                sendto(socketS, resp_msg, (int)strlen(resp_msg), 0, (struct sockaddr*)&dest, sizeof(dest));
                continue;
            }else if (seq_num < expected_seq_num) {
                printf("Already received seq_num . Got %u, expected %u. ACK.\n", seq_num, expected_seq_num);
                snprintf(resp_msg, sizeof(resp_msg), "ACK=%u", seq_num);
                sendto(socketS, resp_msg, (int)strlen(resp_msg), 0, (struct sockaddr*)&dest, sizeof(dest));
                continue;
            }

            char size_str[256];
            if (payload_len <= 0 || payload_len >= (int)sizeof(size_str)) {
                printf("Invalid SIZE payload. NACK.\n");
                snprintf(resp_msg, sizeof(resp_msg), "NACK=%u", seq_num);
                sendto(socketS, resp_msg, (int)strlen(resp_msg), 0, (struct sockaddr*)&dest, sizeof(dest));
                continue;
            }
            memcpy(size_str, payload_data, payload_len);
            size_str[payload_len] = '\0';
            expected_size = atol(size_str);
            printf("File size: %ld bytes\n", expected_size);

            expected_seq_num++;
            snprintf(resp_msg, sizeof(resp_msg), "ACK=%u", seq_num);
            sendto(socketS, resp_msg, (int)strlen(resp_msg), 0, (struct sockaddr*)&dest, sizeof(dest));

        } else if (strcmp(type, "HASH") == 0) {
            if (seq_num > expected_seq_num) {
                printf("Unexpected seq_num for HASH. NACK.\n");
                snprintf(resp_msg, sizeof(resp_msg), "NACK=%u", seq_num);
                sendto(socketS, resp_msg, (int)strlen(resp_msg), 0, (struct sockaddr*)&dest, sizeof(dest));
                continue;
            }else if (seq_num < expected_seq_num) {
                printf("Already received seq_num . Got %u, expected %u. ACK.\n", seq_num, expected_seq_num);
                snprintf(resp_msg, sizeof(resp_msg), "ACK=%u", seq_num);
                sendto(socketS, resp_msg, (int)strlen(resp_msg), 0, (struct sockaddr*)&dest, sizeof(dest));
                continue;
            }

            if (payload_len <= 0 || payload_len >= (int)sizeof(expected_hash)) {
                printf("Invalid HASH payload. NACK.\n");
                snprintf(resp_msg, sizeof(resp_msg), "NACK=%u", seq_num);
                sendto(socketS, resp_msg, (int)strlen(resp_msg), 0, (struct sockaddr*)&dest, sizeof(dest));
                continue;
            }
            memcpy(expected_hash, payload_data, payload_len);
            expected_hash[payload_len] = '\0';
            printf("Expected file hash: %s\n", expected_hash);

            expected_seq_num++;
            snprintf(resp_msg, sizeof(resp_msg), "ACK=%u", seq_num);
            sendto(socketS, resp_msg, (int)strlen(resp_msg), 0, (struct sockaddr*)&dest, sizeof(dest));

        } else if (strcmp(type, "STAR") == 0) {
            // START packet
            if (seq_num > expected_seq_num) {
                printf("Unexpected seq_num for START. NACK.\n");
                snprintf(resp_msg, sizeof(resp_msg), "NACK=%u", seq_num);
                sendto(socketS, resp_msg, (int)strlen(resp_msg), 0, (struct sockaddr*)&dest, sizeof(dest));
                continue;
            }else if (seq_num < expected_seq_num) {
                printf("Already received seq_num . Got %u, expected %u. ACK.\n", seq_num, expected_seq_num);
                snprintf(resp_msg, sizeof(resp_msg), "ACK=%u", seq_num);
                sendto(socketS, resp_msg, (int)strlen(resp_msg), 0, (struct sockaddr*)&dest, sizeof(dest));
                continue;
            }
            started = 1;
            printf("Start receiving data...\n");

            expected_seq_num++;
            snprintf(resp_msg, sizeof(resp_msg), "ACK=%u", seq_num);
            sendto(socketS, resp_msg, (int)strlen(resp_msg), 0, (struct sockaddr*)&dest, sizeof(dest));

        } else if (strcmp(type, "DATA") == 0) {
            if (!started) {
                printf("DATA received before START. NACK.\n");
                snprintf(resp_msg, sizeof(resp_msg), "NACK=%u", seq_num);
                sendto(socketS, resp_msg, (int)strlen(resp_msg), 0, (struct sockaddr*)&dest, sizeof(dest));
                continue;
            }

            // DATA payload: [0..3] offset, [4..end] file data
            if (payload_len < 4) {
                printf("Invalid DATA payload.\n");
                snprintf(resp_msg, sizeof(resp_msg), "NACK=%u", seq_num);
                sendto(socketS, resp_msg, (int)strlen(resp_msg), 0, (struct sockaddr*)&dest, sizeof(dest));
                continue;
            }

            uint32_t net_offset;
            memcpy(&net_offset, payload_data, 4);
            uint32_t offset = ntohl(net_offset);
            const unsigned char* file_data = payload_data + 4;
            int data_len = payload_len - 4;

            if (seq_num == expected_seq_num) {
                if (f) {
                    fseek(f, offset, SEEK_SET);
                    fwrite(file_data, 1, data_len, f);
                }

                printf("Received correct DATA seq=%u, writing %d bytes at offset=%u. ACK.\n", seq_num, data_len, offset);
                snprintf(resp_msg, sizeof(resp_msg), "ACK=%u", seq_num);
                sendto(socketS, resp_msg, (int)strlen(resp_msg), 0, (struct sockaddr*)&dest, sizeof(dest));

                expected_seq_num++;
            } else if (seq_num < expected_seq_num) {
                printf("Duplicate DATA seq=%u. ACK again.\n", seq_num);
                snprintf(resp_msg, sizeof(resp_msg), "ACK=%u", seq_num);
                sendto(socketS, resp_msg, (int)strlen(resp_msg), 0, (struct sockaddr*)&dest, sizeof(dest));
            } else {
                // seq_num > expected_seq_num
                printf("Out-of-order DATA seq=%u, expected=%u. NACK.\n", seq_num, expected_seq_num);
                snprintf(resp_msg, sizeof(resp_msg), "NACK=%u", seq_num);
                sendto(socketS, resp_msg, (int)strlen(resp_msg), 0, (struct sockaddr*)&dest, sizeof(dest));
            }

        } else if (strcmp(type, "STOP") == 0) {
            if (seq_num > expected_seq_num) {
                printf("Unexpected seq_num for STOP. NACK.\n");
                snprintf(resp_msg, sizeof(resp_msg), "NACK=%u", seq_num);
                sendto(socketS, resp_msg, (int)strlen(resp_msg), 0, (struct sockaddr*)&dest, sizeof(dest));
                continue;
            }else if (seq_num < expected_seq_num) {
                printf("Already received seq_num . Got %u, expected %u. ACK.\n", seq_num, expected_seq_num);
                snprintf(resp_msg, sizeof(resp_msg), "ACK=%u", seq_num);
                sendto(socketS, resp_msg, (int)strlen(resp_msg), 0, (struct sockaddr*)&dest, sizeof(dest));
                continue;
            }

            printf("Stop received. Checking file integrity.\n");
            if (f) {
                fclose(f);
                f = NULL;
            }

            // Compute local file hash
            char received_hash[128] = {0};
            {
                char newfilename[512];
                snprintf(newfilename, sizeof(newfilename), "Received_%s", filename);
                if (compute_file_hash(newfilename, received_hash, sizeof(received_hash)) != 0) {
                    printf("Error computing received file hash.\n");
                }
            }

            if (strcmp(expected_hash, received_hash) == 0) {
                printf("File hash matches! File received correctly.\n");
                // char msg[128];
                // snprintf(msg, sizeof(msg), "FILEOK");
                // sendto(socketS, msg, (int)strlen(msg), 0, (struct sockaddr*)&dest, sizeof(dest));
            } else {
                printf("File hash does not match! File corrupted.\n");
                // char msg[128];
                // snprintf(msg, sizeof(msg), "FILECORRUPT");
                // sendto(socketS, msg, (int)strlen(msg), 0, (struct sockaddr*)&dest, sizeof(dest));
            }

            expected_seq_num++;
            snprintf(resp_msg, sizeof(resp_msg), "ACK=%u", seq_num);
            sendto(socketS, resp_msg, (int)strlen(resp_msg), 0, (struct sockaddr*)&dest, sizeof(dest));

            done = 1;

        } else {
            // Unknown type
            printf("Unknown packet type: %s. NACK.\n", type);
            snprintf(resp_msg, sizeof(resp_msg), "NACK=%u", seq_num);
            sendto(socketS, resp_msg, (int)strlen(resp_msg), 0, (struct sockaddr*)&dest, sizeof(dest));
        }
    }

    printf("Receiving finished.\n");
#endif // RECEIVER

    closesocket(socketS);
    WSACleanup();

    getchar(); // wait for press Enter
    return 0;
}
